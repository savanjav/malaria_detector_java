

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

//Program that make binary image base on red,green,blue,gray scale range.
package segment;


import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import malaria.Master;
import malaria.UploadImage;

/**
 *
 * @author SAVAN
 */
 public class Segment1 extends JFrame {
   
    JFrame frame1;
    JLabel imglbl1;
    JLabel output = new JLabel("demo");
    
    JLabel imglbl2;
    JLabel temp;
    String path=UploadImage.getPath();
   //   String path = "virus.jpg";  
    int counter=0;
    int i,j;
    BufferedImage image;
        
     int x=0;int y=0;
     /**
      *
      */
     public int imageWidth,imageHeight;
  //   int binaryimagepixels[][],redbinaryimagepixels[][],greenbinaryimagepixels[][],bluebinaryimagepixels[][],graybinaryimagepixels[][];
    public int[][] red;
    public int[][] green;
    public int blue[][];
    public int intensity[][];
    public int rgba[][];    
     Image binaryImage;
                    int[][] grayrange;
                   
      /**
     *
     */
                    
    
    public Segment1(){
           
                frame1 = new JFrame();
          //      frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame1.setSize(1000,300);
              //  frame1.setVisible(true);
                frame1.setTitle("Color Analyzer");
                Dimension screenSize=Toolkit.getDefaultToolkit().getScreenSize();
                this.setSize(screenSize);
                
  }

    
     /**
     *
     * @throws IOException
     */
    
    
    
    
    public void setImage() throws IOException{
           // path = imagePath;
            File file1 = new File(path);
    
            image = ImageIO.read(file1);
            imglbl1 = new JLabel(new ImageIcon(image));
            frame1.add(imglbl1);
            
            imageWidth=image.getWidth();
            imageHeight=image.getHeight();
            red=new int[imageHeight][imageWidth];
            green=new int[imageHeight][imageWidth];
            blue=new int[imageHeight][imageWidth];
            intensity=new int[imageHeight][imageWidth];
     
            grayrange = new int[imageHeight][imageWidth]; 
           
            rgba = new int[imageWidth][imageHeight];
    }  

    
  
    
    /**
     *
     * @throws IOException
     */
    public int[][] getRGBA() throws IOException{
       // setImage();
    for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
                int intRGB = image.getRGB(j,i);
                
                Color c = new Color(intRGB);
                
                red[i][j]=c.getRed();
                green[i][j]=c.getGreen();
                blue[i][j]=c.getBlue();
                counter++;
                rgba[j][i] = intRGB;
           }
    }
    
    
         
      //  System.out.println("Total"+counter); 
         
    
        
        
        return rgba;
    }
  
  
    
  /**
     *
     */
    @SuppressWarnings("empty-statement")
    public int[][] analyzeImage() throws IOException{
     //   setImage();
        int binaryimagepixels[][] = new int[imageHeight][imageWidth];
         int redbinaryimagepixels[][] = new int[imageHeight][imageWidth];
         int greenbinaryimagepixels[][] = new int[imageHeight][imageWidth];
         int bluebinaryimagepixels[][] = new int[imageHeight][imageWidth];
         int graybinaryimagepixels[][] = new int[imageHeight][imageWidth];
         int finalbinaryimagepixels[][] = new int[imageHeight][imageWidth];
        int segmentimage2[][] = new int[imageHeight][imageWidth];
         
         int rgba[][] = new int[imageHeight][imageWidth];
       
         
         int region1[]=new int[imageHeight*imageWidth];
         int region2[]=new int[imageHeight*imageWidth];
         
       
         
         int binarypixelpointer=0; 
      //   int counter=0;
         int extracomponent=0;
         int rbcdetect=0;
         int rbcpixelcounter=0;
         int extrapixelcounter=0;
         long sum_of_pix=0;
         int regionpointer1=0,regionpointer2=0;
         // initT is shared along gray, red, green, blue analysis.
         int initT,newT = 0;
         int r1Tavg = 0,r2Tavg = 0;
         int n=0,m=0;
         long r1Sum = 0,r2Sum = 0;
         
/*
         for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
                int intRGB = image.getRGB(j,i);
                
                Color c = new Color(intRGB);
                
                red[i][j]=c.getRed();
                green[i][j]=c.getGreen();
                blue[i][j]=c.getBlue();
                counter++;
                rgba[j][i] = (0 << 24) | (red[i][j] << 16) | (green[i][j] << 8) | (blue[i][j] << 0);
                
            
            }
        }
        
         
        System.out.println("Total"+counter); 
  */       
    //--------------------------------- Segmentation ---------------------------------------------------------------------     
        
        
         
            
         for(int analyzer=1;analyzer<=5;analyzer++){   
         
             
            for(i=0;i<imageHeight;i++){
                for(j=0;j<imageWidth;j++){ 
                    switch(analyzer){
                        case 1:  intensity[i][j]=(int)(red[i][j]*0.2989+green[i][j]*0.5870+blue[i][j]*0.1140);break;
                        case 2:  intensity[i][j]=(red[i][j]+green[i][j]+blue[i][j])/3;break;
                        case 3:  intensity[i][j]=red[i][j];break;
                        case 4:  intensity[i][j]=green[i][j];break;
                        case 5: intensity[i][j]=blue[i][j];break;
                  }         
                }
            }
             
             
            int tempcolor = 0;
            initT=0;
            newT = 0;
            r1Tavg = 0;
            r2Tavg = 0;
            
            r1Sum = 0;
            r2Sum = 0;
            
         for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
                tempcolor = intensity[i][j];
                sum_of_pix+=tempcolor;
             }
         }   
            
         initT=(int) (sum_of_pix/counter);
           
         sum_of_pix=0;   
      //   System.out.println("Value of initial thresolding is :" +initT);
         
            
        //set binary pixels
            int tempT=initT;
            int temp1T=0;
        
            while(temp1T!=tempT){
            for(i=0;i<imageHeight;i++)
                {
                    for(j=0;j<imageWidth;j++)
                    { 
                         if(intensity[i][j]>=tempT )
                         {                           
                            region1[regionpointer1]=intensity[i][j];
                            regionpointer1++;
                           switch(analyzer){
                               case 1: binaryimagepixels[i][j]=-16776961;break;
                               case 2: graybinaryimagepixels[i][j]=-16776961;break;
                               case 3: redbinaryimagepixels[i][j]=-16776961;break;
                               case 4: greenbinaryimagepixels[i][j]=-16776961;break;
                               case 5: bluebinaryimagepixels[i][j]=-16776961;break;
                          }
                         }
            
                         else 
                         {                          
                            region2[regionpointer2]=intensity[i][j];
                            regionpointer2++;
                           switch(analyzer){
                               case 1: binaryimagepixels[i][j]=-1;break;
                               case 2: graybinaryimagepixels[i][j]=-1;break;
                               case 3: redbinaryimagepixels[i][j]=-1;break;
                               case 4: greenbinaryimagepixels[i][j]=-1;break;
                               case 5: bluebinaryimagepixels[i][j]=-1;break;
                          }
                        }
                    }
                }
                
                  // System.out.println("total "+regionpointer1);
             for(i=0;i<regionpointer1;i++)
              {
                  r1Sum=r1Sum+region1[i];
              }
            //   System.out.println("vtet"+r1Sum);
              for(i=0;i<regionpointer2;i++)
              {
                  r2Sum=r2Sum+region2[i];
              }
              
              
              r1Tavg= (int)(r1Sum/(regionpointer1+1));
              r2Tavg= (int)(r2Sum/(regionpointer2+1));
              newT=(r1Tavg+r2Tavg)/2;
              temp1T=tempT;
              tempT=newT;
              
             
              regionpointer1=0;
              regionpointer2=0;
              r1Sum=0;
              r2Sum=0;
              r1Tavg=0;
              r2Tavg=0;
             // n=0;m=0;    
              
              
       //          System.out.println("New Thersholding value::"+newT);
          
            }
         
         }     
             
   
         //------------------------------------------------------------------------------------------
         
         
         
         
         //=======Compar all outputs===============================================================
         
         int bluecounter=0,whitecounter=0;
         
         
            for(i=0;i<imageHeight;i++)
            {
                    for(j=0;j<imageWidth;j++){
                            
                            switch(binaryimagepixels[i][j]){
                                case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                            }
                            switch(redbinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            switch(greenbinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            switch(bluebinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            switch(graybinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            
                        if(bluecounter<whitecounter){
                            finalbinaryimagepixels[i][j]=-1;
                            segmentimage2[i][j]=image.getRGB(j, i);
                        }
                        else{
                            finalbinaryimagepixels[i][j]=-16777216;
                            segmentimage2[i][j]=-1;         
                        }
                        whitecounter=0;
                        bluecounter=0;
                    }
            }
         
         
         
         
        
            
            /*
            // ============================ Second Pass For SEgmentation ==========================================            
        int finalbinarypixels1[][] = new int[imageHeight][imageWidth];  
        int pixcounter=0;    
          for(int analyzer=1;analyzer<=5;analyzer++){   
         
             
            for(i=0;i<imageHeight;i++){
                for(j=0;j<imageWidth;j++){ 
                    switch(analyzer){
                        case 1:{ if(finalbinaryimagepixels[i][j]!=-1) intensity[i][j]=(int)(red[i][j]*0.2989+green[i][j]*0.5870+blue[i][j]*0.1140);break;}
                        case 2:{ if(finalbinaryimagepixels[i][j]!=-1) intensity[i][j]=(red[i][j]+green[i][j]+blue[i][j])/3;break;}
                        case 3:{ if(finalbinaryimagepixels[i][j]!=-1)  intensity[i][j]=red[i][j];break;}
                        case 4:{ if(finalbinaryimagepixels[i][j]!=-1)  intensity[i][j]=green[i][j];break;}
                        case 5:{ if(finalbinaryimagepixels[i][j]!=-1) intensity[i][j]=blue[i][j];break;}
                  }         
                }
            }
             System.out.println("Intensity = " + intensity[120][100]);
             
            int tempcolor = 0;
            initT=0;
            newT = 0;
            r1Tavg = 0;
            r2Tavg = 0;
            
            r1Sum = 0;
            r2Sum = 0;
            
         for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
                if(finalbinaryimagepixels[i][j]!=-1){
                    tempcolor = intensity[i][j];
                    sum_of_pix+=tempcolor;
                    pixcounter++;
                }
            }
        }   
            
         initT=(int) (sum_of_pix/pixcounter);
           
         sum_of_pix=0;   
         System.out.println("Value of initial thresolding is :" +initT);
         
            
        //set binary pixels
            int tempT=initT;
            int temp1T=0;
        
            while(temp1T!=tempT){
            for(i=0;i<imageHeight;i++)
                {
                    for(j=0;j<imageWidth;j++)
                    { 
                        if(finalbinaryimagepixels[i][j]!=-1){
                         if(intensity[i][j]>=tempT )
                         {                           
                            region1[regionpointer1]=intensity[i][j];
                            regionpointer1++;
                           switch(analyzer){
                               case 1: binaryimagepixels[i][j]=-16776961;break;
                               case 2: graybinaryimagepixels[i][j]=-16776961;break;
                               case 3: redbinaryimagepixels[i][j]=-16776961;break;
                               case 4: greenbinaryimagepixels[i][j]=-16776961;break;
                               case 5: bluebinaryimagepixels[i][j]=-16776961;break;
                          }
                         }
            
                         else 
                         {                          
                            region2[regionpointer2]=intensity[i][j];
                            regionpointer2++;
                           switch(analyzer){
                               case 1: binaryimagepixels[i][j]=-1;break;
                               case 2: graybinaryimagepixels[i][j]=-1;break;
                               case 3: redbinaryimagepixels[i][j]=-1;break;
                               case 4: greenbinaryimagepixels[i][j]=-1;break;
                               case 5: bluebinaryimagepixels[i][j]=-1;break;
                          }
                        }
                    }
                }
                }
                  // System.out.println("total "+regionpointer1);
             for(i=0;i<regionpointer1;i++)
              {
                  r1Sum=r1Sum+region1[i];
              }
            //   System.out.println("vtet"+r1Sum);
              for(i=0;i<regionpointer2;i++)
              {
                  r2Sum=r2Sum+region2[i];
              }
              
              
              r1Tavg= (int)(r1Sum/(regionpointer1+1));
              r2Tavg= (int)(r2Sum/(regionpointer2+1));
              newT=(r1Tavg+r2Tavg)/2;
              temp1T=tempT;
              tempT=newT;
              
             
              regionpointer1=0;
              regionpointer2=0;
              r1Sum=0;
              r2Sum=0;
              r1Tavg=0;
              r2Tavg=0;
             // n=0;m=0;    
              
              
                 System.out.println("New Thersholding value::"+newT);
          
            }
         
         }     
            
            
            
            
            
            
         //=======Compar all outputs===============================================================
         
          bluecounter=0; whitecounter=0;
         
         
            for(i=0;i<imageHeight;i++)
            {
                    for(j=0;j<imageWidth;j++){
                            if(finalbinarypixels1[i][j]==-1){
                            switch(binaryimagepixels[i][j]){
                                case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                            }
                            switch(redbinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            switch(greenbinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            switch(bluebinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            switch(graybinaryimagepixels[i][j]){
                              case -16776961 : bluecounter++;break;
                                    
                                case -1 : whitecounter++;break;     
                                
                            }
                            
                        if(bluecounter<whitecounter){
                            finalbinarypixels1[i][j]=-1;
                         //   segmentimage2[i][j]=image.getRGB(j, i);
                        }
                        else{
                            finalbinarypixels1[i][j]=-16776961;
                            //segmentimage2[i][j]=-16777216;         
                        }
                        whitecounter=0;
                        bluecounter=0;
                      }
                    }
            }
         
         
*/
            
            
            
            
            
            
            
            
            
            
            
            
 // =============================================================================================================           
            
            
            int[] OneDBinaryDataBackUp = new int[imageHeight*imageWidth];       

                       
         counter=0;   
         for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
              //   OneDBinaryDataBackUp[counter] = finalbinarypixels1[i][j];
              //   OneDBinaryDataBackUp[counter] = finalbinaryimagepixels[i][j];
                 OneDBinaryDataBackUp[counter] = segmentimage2[i][j];
              
                counter++;
            }
         }
     

         
          BufferedImage multicolorimage=new BufferedImage(imageWidth,imageHeight,BufferedImage.TYPE_INT_RGB);
    
         multicolorimage.setRGB(0, 0, imageWidth, imageHeight, OneDBinaryDataBackUp, 0, imageWidth);
         ImageIO.write(multicolorimage, "jpg",new File("Segment2.jpg"));
 
         
         
         
           binaryImage=createImage(new MemoryImageSource(imageWidth, imageHeight, OneDBinaryDataBackUp, 0, imageWidth));
           imglbl2 = new JLabel(new ImageIcon(binaryImage));
            frame1.add(imglbl2);
    
            return finalbinaryimagepixels;
    }
    
  }      
 
