/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package malaria;

import com.mysql.jdbc.Connection;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Yagnik
 */
public class ViewImage extends JFrame
{
    String s1="";
    String pid=SerchRecord.getPid();
   
    JFrame f1;
    JLabel lbl = new JLabel(); 
    Image image;
   
    
    public ViewImage()
    {
                f1 = new JFrame();
                
                f1.setSize(600,600);
                f1.setVisible(true);
                f1.setTitle("Patient Infected Image");
               /* Dimension screenSize=Toolkit.getDefaultToolkit().getScreenSize();
                this.setSize(screenSize);*/
    }
    
    public void setImage() throws IOException
    {
       try
        {
            Class.forName("com.mysql.jdbc.Driver");
	    Connection con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/malaria","root","");
	  
            
            String s="select name from report where patient_id="+pid;
            java.sql.PreparedStatement pst= con.prepareStatement(s);
            ResultSet rs=pst.executeQuery(s);
            while(rs.next())
            {          
                
                s1=rs.getString(1); 
           
            }
            con.close();
        }
        catch(ClassNotFoundException ce)
        {
            System.out.println(ce);
        }
        catch(SQLException se)
        {
            System.out.print(se);
	}
	catch(Exception e)
	{
            System.out.print(e);
	} 
         
        String path=pid+ "/" +s1;        
        File f=new File(path);
        image = ImageIO.read(f);
        lbl = new JLabel(new ImageIcon(image));
        f1.add(lbl);
    }    
}
 