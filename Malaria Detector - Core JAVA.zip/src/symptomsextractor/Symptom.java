/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package symptomsextractor;

import java.io.IOException;

/**
 *
 * @author Nayan
 */
public class Symptom {
    
    public static void main(String args[]) throws IOException{
        
        SymptomsExtractor c1 = new SymptomsExtractor();
              c1.setImage();       
              c1.analyzeImage();
    
    }
    
    
}
