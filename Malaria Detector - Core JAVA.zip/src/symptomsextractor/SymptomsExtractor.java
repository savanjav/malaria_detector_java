
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package symptomsextractor;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import malaria.Master;
import malaria.UploadImage;

/**
 *
 * @author SAVAN
 */



 public class SymptomsExtractor extends JFrame {
   
    JFrame frame1;
    JLabel imglbl1;
    JLabel output=new JLabel();
    
    JLabel imglbl2;
    JLabel temp;
    String path ="Segment2.jpg";
    int counter=0;
    
    int i,j;
    String spath=UploadImage.getPath();
    File file1 = new File(path);
    BufferedImage image;
        
     int x=0;int y=0;
     int imageWidth,imageHeight;
     int[][] red;
     int[][] green;
     int[][] blue; 
     int[][] grayRGBA;    
     int[][] grayColor;
     Image binaryImage;
    private int Algerian;
        
     public SymptomsExtractor(){
                frame1 = new JFrame();
                frame1.setLayout(new GridLayout());
                //.add(imglbl2);
                frame1.setSize(1200,600);
                //frame1.setLocation(200,200);
                frame1.setVisible(true);
                frame1.setTitle("Malaria Detector");
                frame1.add(output);
                //this.add(output);
                Dimension screenSize=Toolkit.getDefaultToolkit().getScreenSize();
                this.setSize(screenSize);
                
                //output.setBackground(Color.red);
             
       }
    public void setImage() throws IOException{
            image = ImageIO.read(file1);
            imglbl2 = new JLabel(new ImageIcon(image));     
            imageWidth=image.getWidth();
            imageHeight=image.getHeight();
            red=new int[imageHeight][imageWidth];
            green=new int[imageHeight][imageWidth];
            blue=new int[imageHeight][imageWidth];   
            grayRGBA = new int[imageHeight][imageWidth]; 
            grayColor = new int[imageHeight][imageWidth]; 
     
    }
    @SuppressWarnings("empty-statement")
    public int[][] analyzeImage() throws IOException{
         int binaryimagepixels[][] = new int[imageHeight][imageWidth];
         
         int binarypixelpointer=0; 
         int counter1=0;
         int extracomponent=0;
         int rbcdetect=0;
         int rbcpixelcounter=0;
         int extrapixelcounter=0;
            
        for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
                int intRGB = image.getRGB(j,i);
                Color c = new Color(intRGB);
                
                red[i][j]=c.getRed();
                green[i][j]=c.getGreen();
                blue[i][j]=c.getBlue();
                counter++;
            }
        }
            //Color Analysis.
        int rgba = -1,tempcolor = 0,tempgreen = 0,tempblue=0;
        for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
                tempcolor=(red[i][j]+green[i][j]+blue[i][j])/3;
              
                
                //  System.out.println("Gray Lvl = " + tempcolor);    
                rgba = (255 << 24) | (tempcolor << 16) | (tempcolor << 8) | (tempcolor);
              
                       grayRGBA[i][j]=rgba;
                       grayColor[i][j]=tempcolor;
                       if(grayColor[i][j]<=150){ 
                           
                           binaryimagepixels[i][j] = -16777016;
                       }
                       
                       else{
                           binaryimagepixels[i][j] = -1;
                           
                       }
            }
        }

        
          int malaria = 0;
          int[] oneD = new int[imageHeight*imageWidth];  
            counter=0;
         for(i=0;i<imageHeight;i++){
            for(j=0;j<imageWidth;j++){ 
                    //  oneD[counter] = grayRGBA[i][j];
                      oneD[counter] = binaryimagepixels[i][j];
                
                      if(binaryimagepixels[i][j]!=-1){
                          malaria = 1;
                      }
                      counter++;
                      
            } 
            
         }
         
         
         JLabel output1 = new JLabel();
         if(malaria==1)
         {
             output.setBounds(300, 500, 10, 20);
             output.setText("Malaria symptoms Detected");            
             Font f = new Font("", Font.CENTER_BASELINE,40);
             output.setForeground(Color.red);
             output.setFont(f);       
           
          }
          else
          {
             output.setText("Malaria Negative");
             Font f = new Font("", Font.CENTER_BASELINE,55);
             output.setForeground(Color.green);
             output.setFont(f);
             //output.setBounds(300, 500, 10, 20);
          }
         
           binaryImage=createImage(new MemoryImageSource(imageWidth, imageHeight, oneD, 0, imageWidth));;
           
           imglbl2 = new JLabel(new ImageIcon(binaryImage));
           imglbl2.setBounds(300, 10, imageWidth, imageHeight);
           frame1.add(imglbl2);
           frame1.add(output);
           return binaryimagepixels;
     }
 }

