	

package Label;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import segment.Segment1;
import symptomsextractor.SymptomsExtractor;

public class Label 
{
    int counter=0;
    int i,j;
    int x=0;int y=0;
    int imageWidth,imageHeight;
    BufferedImage binary,segmentedImage;
   public int lable[][];
    int binaryimage[][];
    int rgba[][];
    
    /**
     *
     */
    public Label()
    {
     
    }

     
    
    public void setImage() throws IOException
    {
  
            Segment1 s1 = new Segment1();    
            s1.setImage(); 
            imageWidth = s1.imageWidth;
            imageHeight = s1.imageHeight;
            lable = new int[imageWidth][imageHeight];
            rgba = new int[imageWidth][imageHeight];
     

            
    }
    
    //---------------------------------
    
    public int getImageWidth(){
       
        return imageWidth ;
        
    }
    
    public int getImageHeight(){
        
        return imageHeight ;
        
    }
    
    //---------------------------------
    
    int clable;
    int assignpair[] = new int[50];
    int toppair[] = new int[50000];
    int leftpair[] = new int[50000];
    int pairpointer=1;
    
    int uniqlable[] = new int[imageWidth*imageHeight],ulpointer=0;
     
 
    
    /**
     *
     * @throws IOException
     */
    public int[][] analyzeImage() throws IOException{
    Segment1 s1 = new Segment1(); 
    s1.setImage();
    rgba = s1.getRGBA();
    binaryimage = s1.analyzeImage();
    
        leftpair[0]=-1;
        
        // First pass for give lable to binary image and store lables in lable array.
        for(j=1;j<imageHeight;j++){
            for(i=1;i<imageWidth;i++){
                // if current pixel is blue
               // if(binaryimage[j][i]==-16776961 ){
                      if(binaryimage[j][i]==-1 ){
                    
                  
                    // Check if left and top lable is set or not. 
                   if(lable[i-1][j]!=0 && lable[i][j-1]!=0){
                       
                       
                       // Check if left and top lable is same or not. 
                       if(lable[i-1][j]==lable[i][j-1]){
                           lable[i][j] = lable[i-1][j];
                       }
                   
                       
                       
                       else{
                           lable[i][j]=lable[i-1][j];
                           if(leftpair[pairpointer-1]!=lable[i-1][j]){
                            leftpair[pairpointer]=lable[i-1][j];
                            toppair[pairpointer]=lable[i][j-1];
                            pairpointer++;
                       
                           }
                       //    System.out.println("Left Pair = " + leftpair[pairpointer] + "Top Pair = " + toppair[pairpointer]);

                        }
                   
                }
                
                   else if(lable[i-1][j]!=0 && lable[i][j-1]==0){
                       lable[i][j]=lable[i-1][j];
                   }   
                   
                   else if(lable[i-1][j]==0 && lable[i][j-1]!=0){
                       lable[i][j]=lable[i][j-1];
                   }   
                   
                // if not any set.
                   else{
                     lable[i][j]=clable;
                     clable++;
                   }    
                }
            }
        }
   
           
        // Second Pass.
        
        int findelement;
        int replaceelement;
        for(int k=1;k<pairpointer;k++){
          replaceelement=leftpair[k];
          findelement=toppair[k]; 
         // System.out.println("leftpair=" + leftpair[k]);
        //  System.out.println("toppair=" + toppair[k]);          
          for(j=1;j<imageHeight;j++){
                for(i=1;i<imageWidth;i++){
                    if(lable[i][j]==findelement){
                        lable[i][j]=replaceelement;
                    }
                }   
          }
        
       }
        

//========================================================       
//Set Uniq Lable Arr.
short dupUL=0;
int uniql[] = new int[1000];

for(i=1;i<clable;i++){
    for(j=1;j<pairpointer;j++){
        if(i==toppair[j]){
            dupUL=1;
        }
    }

    if(dupUL!=1){
        uniql[ulpointer]=i;
      //  System.out.println("Unoq lable ="+ uniql[ulpointer] );
        ulpointer++;
    }
    dupUL=0;
}        
          


// Fill Binary RBC

        
        int currentPosX=0;
        int currentPosY=0;
        int innerLableValue=3;
        int leftLable = 0, topLable = 0, rightLable = 0 , bottomLable = 0;
        int comparLable=0;
        int decision1=1,decision2=1,decision3=1,decision4=1;
        
        
        int left,right,top,bottom;
 
        for(j=0;j<imageHeight-1;j++){
            for(i=0;i<imageWidth-1;i++){
                
                currentPosX=i;
                currentPosY=j;
                
                
                    if(lable[i][j]==0){
                        
                        for(right=currentPosX;right<imageWidth;right++){
                            // currentPosX=i+1;
                
                            if(lable[right][j]!=0){
                                    rightLable=lable[right][j];
                                    break;
                            }
                        }
                    
                    
                       for(left=currentPosX;left>0;left--){
                           //  currentPosX=i-1;
                
                            
                            if(lable[left][j]!=0){
                                leftLable=lable[left][j];
                                break;
                            }
                        }
                    

                       for(bottom=currentPosY;bottom<imageHeight;bottom++){
                            if(lable[i][bottom]!=0){
                                bottomLable=lable[i][bottom];
                                break;
                            }
                            
                       }

                       
                       
                       for(top=currentPosY;top>0;top--){
                            if(lable[i][top]!=0){
                                topLable=lable[i][top];
                                break;
                            }
                       }
                       
                        //Check the posibility of pixel in object by evaluating all positions.
                       
                       for(int k=0;k<4;k++){
                           if(k==0){ 
                              comparLable=leftLable;
                              if(comparLable==rightLable  || comparLable == innerLableValue)decision1++;
                              if(comparLable==topLable || comparLable == innerLableValue)decision1++;
                              if(comparLable==bottomLable || comparLable == innerLableValue)decision1++;
                            //  System.out.println("Decision1 =" +decision1);
                              if(decision1>=3) break;
                           }
                       
                           if(k==1){ 
                              comparLable=rightLable;
                              if(comparLable==leftLable || comparLable == innerLableValue)decision2++;
                              if(comparLable==topLable || comparLable == innerLableValue)decision2++;
                              if(comparLable==bottomLable || comparLable == innerLableValue)decision2++;
                          
                              if(decision2>=3) break;
                           }
                       
                       
                           if(k==2){ 
                              comparLable=top;
                              if(comparLable==leftLable || comparLable == innerLableValue)decision3++;
                              if(comparLable==rightLable || comparLable == innerLableValue)decision3++;
                              if(comparLable==bottomLable || comparLable == innerLableValue)decision3++;
                          
                              if(decision3>=3) break;
                              
                           }
                         
                       
                        
                           if(k==3){ 
                              comparLable=bottom;
                              if(comparLable==leftLable || comparLable == innerLableValue)decision4++;
                              if(comparLable==rightLable || comparLable == innerLableValue)decision4++;
                              if(comparLable==topLable || comparLable == innerLableValue)decision4++;
                          
                              if(decision4>=3) break;
                              
                          }
                           
                       
                        }
                       
                       
                       
                      // Replace inner object lable with -3 if any to or more neighbours are not zero.
                       
                       
                      int zeroLable = 0;
                      
                      if(leftLable==0)zeroLable++;
                      if(topLable==0)zeroLable++;
                      if(rightLable==0)zeroLable++;
                      if(bottomLable==0)zeroLable++;
                      
                    // System.out.println("ZerLable = " + zeroLable);   
                      if(zeroLable<2){
                                                
                           if(decision1>=4 || decision2>=4 || decision3>=4 || decision4>=4){
                           lable[i][j] = innerLableValue ;
                           
                        }
                     }
                     
                    // System.out.println("Decision1 = " +decision1);
                   //  System.out.println("Decision2 = " +decision2);
                    // System.out.println("Decision3 = " +decision3);
                   //  System.out.println("Decision4 = " +decision4);
                     
                     leftLable=0;rightLable=0;topLable=0;bottomLable=0;
                     left=0;right=0;top=0;bottom=0;
                     decision1=1;decision2=1;decision3=1;decision4=1;
                       zeroLable=0;
                       comparLable=0;
                    }
                    
                    
            }
            
        }
       

      
      int[] OneDBinaryDataBackUp = new int[imageHeight*imageWidth];       
        
      int counter1=0;
        
       for(j=0;j<imageHeight;j++){
                for(i=0;i<imageWidth;i++){
                    if(lable[i][j]!=0){
                        
                        OneDBinaryDataBackUp[counter1]= rgba[i][j];
                   
                    
                    }
                   // System.out.println(OneDBinaryDataBackUp[counter]);
                    counter1++;
                
                }
       
               // System.out.println(" ");
       }

       

       
         BufferedImage multicolorimage=new BufferedImage(imageWidth,imageHeight,BufferedImage.TYPE_INT_RGB);
    
         multicolorimage.setRGB(0, 0, imageWidth, imageHeight, OneDBinaryDataBackUp, 0, imageWidth);
         ImageIO.write(multicolorimage, "jpg",new File("Segment3.jpg"));
 

         
  
         /*
//Result displa
          for(j=1;j<imageHeight;j++){
                for(i=1;i<imageWidth;i++){
                  System.out.print(lable[i][j]);
               }
                  System.out.println("-");
         
          }
          */
          
        return lable;
       }



    public int[][] getLable(){
        return lable;
    }

    //==================================================================
    
    int symptoms[][] = new int[imageHeight][imageWidth];
        public void checkPosition() throws IOException{
            setImage();
            analyzeImage();
            SymptomsExtractor se1 = new SymptomsExtractor();
            
            se1.setImage();
           
            symptoms = se1.analyzeImage();
            
       //     System.out.println("Position Check function call /");
            
           // Function of Label
          
            // Function of Symptoms
          
            /*
           System.out.println("======================Lable Valuse are : ");
            for(i=0;i<imageWidth;i++){
                for(j=0;j<imageHeight;j++){
            
                 System.out.print(lable[i][j]);
                
                }
                System.out.println(" ");
            }

            
            
            System.out.println("======================Symptoms Valuse are : ");
            for(i=0;i<imageHeight;i++){
                for(j=0;j<imageWidth;j++){
                    System.out.print(symptoms[i][j]);
                
                }
                System.out.println(" ");
            }
        
            */
              
             }

             






}    
