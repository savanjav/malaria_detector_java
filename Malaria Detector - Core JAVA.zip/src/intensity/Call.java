/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package intensity;

import java.io.IOException;

/**
 *
 * @author Nayan
 */
public class Call
{
    public static void main(String ar[]) throws IOException
            {
                PixelIntensity p=new PixelIntensity();
                p.setImage();
                p.analyzeImage();
            }
}
