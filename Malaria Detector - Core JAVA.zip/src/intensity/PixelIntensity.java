/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package intensity;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.MemoryImageSource;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author Nayan
 */
public class PixelIntensity extends JFrame 
{
   
    JFrame frame1;
    JLabel imglbl1;
    JLabel output = new JLabel();
    
    JLabel imglbl2;
    JLabel temp;
    String path="Malaria_1.jpg";
    int counter=0;
 
    int i,j;
    File file1 = new File(path);
    BufferedImage image;
    Image segmentImage;
        
     int x=0;int y=0;
     int imageWidth,imageHeight;    
     int[][] red;
     int[][] green;
     int blue[][];
     int alpha[];
     
     PixelIntensity()
     {
                frame1 = new JFrame();
                frame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                //frame1.add(imglbl1);
                frame1.setSize(1000,600);
               // frame1.setLocation(200,200);
                frame1.setVisible(true);
                frame1.setTitle("Get Intensity");
              //  frame1.add(output);
               // Dimension screenSize=Toolkit.getDefaultToolkit().getScreenSize();
               // this.setSize(screenSize);
     }
     
      public void setImage() throws IOException
      {
            image = ImageIO.read(file1);
            imglbl1 = new JLabel(new ImageIcon(image));
            frame1.add(imglbl1);
            
            imageWidth=image.getWidth();
            imageHeight=image.getHeight();
            red=new int[imageHeight][imageWidth];
            green=new int[imageHeight][imageWidth];
            blue=new int[imageHeight][imageWidth];                 
     }  
      
      public void analyzeImage() throws IOException
      {
          int i,j,initT=0;
          int count=0;
           int sum=0;
          int intensity[][]=new int[imageHeight+2][imageWidth+2];
          for(x=0;x<imageHeight;x++)
          {
              for(y=0;y<imageWidth;y++)
              {
                  int RGB=image.getRGB(y,x);
                  Color c = new Color(RGB);
                  red[x][y]=c.getRed();
                  green[x][y]=c.getGreen();
                  blue[x][y]=c.getBlue();
                  count++;
              }
          }
          System.out.println("Total pixel"+count);
          for(x=0;x<imageHeight;x++)
          {
              for(y=0;y<imageWidth;y++)
              {
                  
                  intensity[x][y]=(int)(red[x][y]*0.2989+green[x][y]*0.5870+blue[x][y]*0.1140);
                 // System.out.println(intensity[x][y]);
              }
          }
          for(x=0;x<imageHeight;x++)
          {
              for(y=0;y<imageWidth;y++)
              {
                 
                  sum=sum+intensity[x][y];
                  initT=sum/count;
              }   
          }
       System.out.println("Initial Thresholding::"+initT);
      }
                
} 

    

